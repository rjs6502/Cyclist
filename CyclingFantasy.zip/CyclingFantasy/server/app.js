var _ = require('underscore'),
	app = require('express')(),
	fs = require('fs'),
	http = require('http'),
	path = require('path'),
	router = require('./router/router');

router(app);

app.listen( 3000, function() {
	console.log('Cycling Fantasy App running on port 3000');
});