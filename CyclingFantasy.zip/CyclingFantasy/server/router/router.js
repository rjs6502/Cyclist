var _ = require('underscore'),
	fs = require('fs'),
	http = require('http'),
	path = require('path'),
	homePage = path.resolve('./views/index.html');

	appIndex = function(req, res){
		res.sendFile(homePage);
	};

module.exports = function(app) {
	
	//home
	app.get('/', appIndex);
};